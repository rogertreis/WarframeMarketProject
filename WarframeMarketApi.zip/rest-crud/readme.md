
## Installation

    cd rest-crud

    npm install

## Configuration (database)
server.js

connection(mysql,{
        host     : 'localhost',
        user     : 'root',
        password : 'root',
        database : 'mydb',
        debug    : false //set true if you wanna see debug logger
    }


	
You're gonna need to create a DB named 'mydb' or whatever you name it,  import db.sql


## Running

node server.js

If you want to define a port: PORT=XXXX node server.js

Open your browser: localhost:3000

Routes are as follows: localhost:3000/api/route

Ex.: localhost:3000/api/trade